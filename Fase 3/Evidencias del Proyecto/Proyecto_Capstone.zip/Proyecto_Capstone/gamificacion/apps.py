from django.apps import AppConfig


class GamificacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gamificacion'
